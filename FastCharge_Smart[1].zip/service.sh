#!/system/bin/sh
(
sleep 40
BAT="/sys/class/power_supply/battery"

while true; do
    TEMP=$(cat $BAT/temp)

    # Nivel 1: Frio (< 39°C) -> Carga Maxima (Aprox 4.5A)
    if [ "$TEMP" -lt "390" ]; then
        echo 4500000 > $BAT/constant_charge_current_max
        echo 1 > $BAT/fast_chg_force
        echo 0 > $BAT/charge_control_limit

    # Nivel 2: Tibio (39°C - 43°C) -> Carga Moderada (Aprox 2.8A)
    elif [ "$TEMP" -lt "430" ]; then
        echo 2800000 > $BAT/constant_charge_current_max
        echo 1 > $BAT/fast_chg_force
        echo 1 > $BAT/charge_control_limit

    # Nivel 3: Caliente (43°C - 45°C) -> Carga Lenta Segura (Aprox 1.5A)
    elif [ "$TEMP" -lt "450" ]; then
        echo 1500000 > $BAT/constant_charge_current_max
        echo 0 > $BAT/fast_chg_force
        echo 1 > $BAT/charge_control_limit

    # Nivel 4: Critico (> 45°C) -> Carga minima de proteccion
    else
        echo 500000 > $BAT/constant_charge_current_max
        echo 0 > $BAT/fast_chg_force
        echo 1 > $BAT/charging_enabled
    fi
    
    sleep 30
done
) &
